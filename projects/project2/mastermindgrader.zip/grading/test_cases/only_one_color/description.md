#only_one_color
