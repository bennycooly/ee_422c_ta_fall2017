#only_one_peg_win
